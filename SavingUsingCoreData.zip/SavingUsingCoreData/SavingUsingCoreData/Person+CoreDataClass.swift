//
//  Person+CoreDataClass.swift
//  SavingUsingCoreData
//
//  Created by Nishit on 2018-02-17.
//  Copyright © 2018 Nishit. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Person)
public class Person: NSManagedObject {

}
